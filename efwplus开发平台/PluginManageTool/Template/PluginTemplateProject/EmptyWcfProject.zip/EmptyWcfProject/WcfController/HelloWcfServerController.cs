﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EFWCoreLib.CoreFrame.Business.AttributeInfo;
using EFWCoreLib.WcfFrame.ServerController;

namespace ${TemplateData.PluginName}.WcfController
{
    [WCFController]
    public class HelloWcfServerController : JsonWcfServerController
    {
        [WCFMethod]
        public string GetHello()
        {
            return ToJson("hello world !");
        }
    }
}

