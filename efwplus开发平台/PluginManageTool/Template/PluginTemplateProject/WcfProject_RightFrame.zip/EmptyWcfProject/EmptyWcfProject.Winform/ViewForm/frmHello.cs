﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EFWCoreLib.WcfFrame.ClientController;
using ${TemplateData.PluginName}.Winform.IView;

namespace ${TemplateData.PluginName}.Winform.ViewForm
{
    public partial class frmHello : BaseForm, IfrmHello
    {
        public frmHello()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            InvokeController("Exit");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(InvokeController("GetHello").ToString());
        }

      
    }
}
