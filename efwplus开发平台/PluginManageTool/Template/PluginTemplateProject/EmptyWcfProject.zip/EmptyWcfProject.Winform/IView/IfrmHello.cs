﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EFWCoreLib.WcfFrame.ClientController;

namespace ${TemplateData.PluginName}.Winform.IView
{
    public interface IfrmHello : IBaseView
    {
    }
}
