﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EFWCoreLib.WebFrame.TemplateHandler;
using EFWCoreLib.CoreFrame.Business.AttributeInfo;
using EFWCoreLib.CoreFrame.EntLib.Aop;

namespace ${TemplateData.PluginName}.WebController
{
    [WebController]
    public class TestTemplateController : TemplateController
    {
        

        [WebMethod]
        [AOP(typeof(HeadComponent), typeof(FooterComponent))]
        public void Razortest01()
        {
            List<string> data = new List<string>();
            data.Add("选项1");
            data.Add("选项2");
            data.Add("选项3");
            ViewData.Add("data", data);

            ViewData.Add("name", "kakake");
            ViewResult = ToView(@"${TemplateData.PluginName}\templatefile\test01.cshtml");
        }
    }

    public class HeadComponent : AbstractRazorComponent
    {
        public override string GetFilePath()
        {
            return "${TemplateData.PluginName}/templatefile/head.cshtml";
        }

        public override void LoadViewData()
        {
            ViewData.Add("head", "这是页头！");
        }
    }

    public class FooterComponent : AbstractRazorComponent
    {
        public override string GetFilePath()
        {
            return "${TemplateData.PluginName}/templatefile/footer.cshtml";
        }

        public override void LoadViewData()
        {
            ViewData.Add("footer", "这是页脚！");
        }
    }


}
