﻿//function login(){
//    formSubmit('#loginform',{cmd:'Controller.aspx?controller=WebTest01@HelloController&method=test02_login'},function(ret){
//        window.location.href = "API.aspx?cmd=test_loginsuccess";
//    });
//}

function check(){
    if($('#name').val()==""){
        alert("用户名不能为空！");
        return false;
    } 
    
    if($('#pass').val()==""){
        alert("密码不能为空！");
        return false;
    } 
    
     return true;
}

function cbLoadData() {

    simpleAjax("Controller.aspx?controller=WebTest01@TestTemplateController&method=test03_ajaxdata",{},function(ret){
        $('#cb02').combobox('loadData',ret);
    });
}

