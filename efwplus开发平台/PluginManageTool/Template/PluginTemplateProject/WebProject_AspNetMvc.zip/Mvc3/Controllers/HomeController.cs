﻿using EFWCoreLib.WebFrame.AspNetMvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Mvc3.Controllers
{
    public class HomeController : MvcController
    {
        protected override void Initialize(System.Web.Routing.RequestContext requestContext)
        {
            InitPlugin("${TemplateData.PluginName}");
            base.Initialize(requestContext);
        }

        public ActionResult Index()
        {
            ViewBag.Message = "欢迎使用 ASP.NET MVC!" + oleDb.GetDataResult("select 'hello'") + _pluginName; ;
            
            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
