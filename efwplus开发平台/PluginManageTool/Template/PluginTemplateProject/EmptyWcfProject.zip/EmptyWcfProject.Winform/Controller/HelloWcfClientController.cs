﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EFWCoreLib.WcfFrame.ClientController;
using EFWCoreLib.CoreFrame.Business.AttributeInfo;
using ${TemplateData.PluginName}.Winform.IView;

namespace ${TemplateData.PluginName}.Winform.Controller
{
    [WinformController(DefaultViewName = "frmHello")]//在菜单上显示
    [WinformView(Name = "frmHello", DllName = "${TemplateData.PluginName}.Winform.dll", ViewTypeName = "${TemplateData.PluginName}.Winform.ViewForm.frmHello")]//控制器关联的界面
    public class HelloWcfClientController : JsonWcfClientController
    {
        IfrmHello _ifrmhello;
        public override void Init()
        {
            _ifrmhello = (IfrmHello)DefaultView;
        }

        [WinformMethod]
        public string GetHello()
        {
            Object retdata = InvokeWCFService("HelloWcfServerController", "GetHello");
            return ToString(retdata);
        }
    }
}

