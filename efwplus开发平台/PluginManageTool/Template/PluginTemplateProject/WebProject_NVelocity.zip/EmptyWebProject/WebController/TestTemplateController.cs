﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EFWCoreLib.WebFrame.TemplateHandler;
using EFWCoreLib.CoreFrame.Business.AttributeInfo;
using EFWCoreLib.CoreFrame.EntLib.Aop;

namespace ${TemplateData.PluginName}.WebController
{
    [WebController]
    public class TestTemplateController : TemplateController
    {
        [WebMethod]
        public void test01()
        {
            List<object> data = new List<object>();
            data.Add(new { id = 1, name = "选项1" });
            data.Add(new { id = 2, name = "选项2" });
            data.Add(new { id = 3, name = "选项3" });
            data.Add(new { id = 4, name = "选项4" });
            data.Add(new { id = 5, name = "选项5" });

            ViewData.Add("combox_data", ToJson(data));

            ViewResult = ToView(@"${TemplateData.PluginName}\templatefile\test01.htm");
        }
        [WebMethod]
        public void test02()
        {
            ViewResult = ToView(@"${TemplateData.PluginName}\templatefile\test02.htm");
        }
        [WebMethod]
        public void test02_login()
        {
            string name = FormData["name"];
            string pass = FormData["pass"];
            ViewData.Add("name", name);
            ViewData.Add("pass", pass);

            ViewResult = ToView(@"${TemplateData.PluginName}\templatefile\test02_loginsuccess.htm");
        }
        [WebMethod]
        public void test03()
        {
            ViewResult = ToView(@"${TemplateData.PluginName}\templatefile\test03.htm");
        }
        [WebMethod]
        public void test03_ajaxdata()
        {
            List<object> data = new List<object>();
            data.Add(new { id = 1, name = "选项1" });
            data.Add(new { id = 2, name = "选项2" });
            data.Add(new { id = 3, name = "选项3" });
            data.Add(new { id = 4, name = "选项4" });
            data.Add(new { id = 5, name = "选项5" });

            JsonResult = ToJson(data);
        }


    }



}
